
export const SUPPORTED_LANGUAGES: string[] = [
  'English', 
  'Spanish', 
  'French', 
  'German', 
  'Chinese', 
  'Japanese', 
  'Korean',
  'Arabic',
  'Hindi', 
  'Bengali', 
  'Tamil', 
  'Telugu', 
  'Kannada', 
  'Malayalam', 
  'Marathi', 
  'Gujarati', 
  'Punjabi', 
  'Urdu', 
  'Bhojpuri'
];
